package com.example.applemusicui.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.applemusicui.ui.screens.SearchScreen
import com.example.applemusicui.ui.theme.AppleMusicUITheme
import com.example.applemusicui.ui.theme.AppThemeMode

@Composable
fun AppRoot() {
    var themeMode by remember { mutableStateOf(AppThemeMode.SYSTEM) }

    AppleMusicUITheme(themeMode = themeMode) {
        Scaffold { innerPadding ->
            // Menampilkan SearchScreen dengan state tema yang aktif
            SearchScreen(
                currentThemeMode = themeMode,
                onThemeModeChange = { newMode ->
                    themeMode = newMode
                }
            )
        }
    }
}
