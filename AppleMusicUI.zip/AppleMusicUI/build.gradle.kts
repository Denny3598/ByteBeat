dependencies {
    // Kode dependency bawaan kamu yang sudah ada tetap dibiarkan ...

    // --- Tambahan Pustaka Pemutar Audio (Media3 ExoPlayer) ---
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-session:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")

    // --- Tambahan Pustaka Network & JSON Parser ---
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")
}
